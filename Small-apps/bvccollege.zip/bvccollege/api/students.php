

<?php



    if($method == 'GET'){
   

      if($id){
  
        $data = Database::query("SELECT * FROM $tableName WHERE id=:id", array(':id'=> $id));

        
       if($data !=null){

          echo json_encode($data[0]);
          
        
      }
      else{

          echo json_encode(['message'=> 'Currently there are no students in the database.']);

      }
       
     
    }else{
  
        $data = Database::query("SELECT * FROM $tableName");

        echo json_encode($data);
       
    }
}

elseif($method == 'POST'){

  
    if($_POST != null && !$id){
 
         extract($_POST);
        // print_r($student_name);
        Database::query("INSERT INTO $tableName VALUES(null, :student_name, :student_number, :student_age)", array
        (':student_name'=> $student_name,':student_number'=> $student_number, ':student_age'=> $student_age));

        $data = Database::query("SELECT * FROM $tableName ORDER BY id DESC LIMIT 1");

        echo json_encode(['message' => 'Post added to the database.', 'success' => true, 'post'=> $data[0]]);
    }
    else{
      
        
        echo json_encode(['message' => 'Please Fill all the credentials.', 'success' => false]);

    }

}elseif($id){

  $post = Database::query("SELECT * FROM $tableName WHERE id=:id", array(':id' => $id));

  if($post !=null){
      
    if($method =='PUT'){

        $_PUT = json_decode(file_get_contents('[h[://input'));
        print_r($_PUT); 

    } elseif($method == 'DELETE'){

        Database::query("DELETE FROM $tableName WHERE id=:id", array(':id' => $id));

        echo json_encode(['post' => $data[0],'message' => 'Post delted from the database','success' => true]);

    }

  }
  else{

    echo json_encode (['message'=>'There is problem', 'success' => false]);
  }
      
}





?>





