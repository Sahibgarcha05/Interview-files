<?php


////i used this for url so like if you put student/ it will retrive data from the table////

header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Methods: POST, GET, DELETE,PUT');


$method = $_SERVER['REQUEST_METHOD'];


$request_uri = $_SERVER['REQUEST_URI'];



$tables = ['students'];

$url =  rtrim($request_uri,'/');

$url = filter_var($request_uri, FILTER_SANITIZE_URL);

$url = explode('/',$url);


$tableName= (string) $url[3];


if($url[4]!= null){

    $id = (int) $url[4];

}else{

 $id = null;
}
 if(in_array($tableName, $tables)){

   
    include_once './classes/Database.php';
    include_once './api/students.php';

      
 }else{

    echo 'Table Does Not exist';
 }


 


 