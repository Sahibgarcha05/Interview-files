///
/// FilteredInput
///

import React, { Component } from 'react';
//import './filtered-input.css';

///
/// FilteredInput
///
/// Props --
/// initialvalue: sets the initial value in the box.
/// filter: a regex filter to screen input characters.
/// ondone: a callback function to signal that the user has finished.
///
export class FilteredInput extends Component {

	///
	constructor(props) {
		super(props);
		this.state = { Value:this.props.initialvalue }
	}

	///
	OnInput = (e) => {

		// Extract the input value from the event object.
		let InputValue = e.target.value;

		// Use a regex to strip out characters not in the input string.
		var Filter = this.props.filter;
		var Regex = new RegExp(Filter, 'g');
		InputValue = InputValue.replace(Regex, "");

		// Update state with the filtered result.
		this.setState({ Value:InputValue });

	}

	///
	OnBlur = (e) => {
		if (this.props.ondone) this.props.ondone(this.state.Value);
	}
	
	///
	render() {

		/// Render markup.
		return (

			<input className="filtered-input-box" type="text" 
				onInput={this.OnInput} 
				onBlur={this.OnBlur} 
				value={this.state.Value} />

		);

	}
	
}