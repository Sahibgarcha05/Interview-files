import React, {Component} from 'react' ;
import {FilteredInput} from './filtered-input' ;


class App extends Component{

    constructor(props){
      super(props);

      this.state={
        newItem:"",
        list:[]
      }

    }

updateInput(key,value){
  this.setState({
    [key]:value
  });
}



addItem(){
  //create item with unique ID
  const newItem={
    id: 1 + Math.random(),
    value:this.state.newItem.slice()
  };

  //copy of curernt list
  const list = [...this.state.list,newItem];

  //add new item to list
  //list.push(newItem);

  //update state with new list and reset new input
  this.setState({
    list,
    newItem:""
  });


}

//************* */

deleteItem(id){
  const list = [...this.state.list];
  const updateList = list.filter(item => item.id !==id);

  this.setState({list:updateList});
}

//********


  render(){
    return(
      <div className="App">
        
           <div>
            Add an Items to do here...
            <br/>
              <input
              type="text"
              placeholder="Tye here..."
             
              value={this.state.newItem}
              onChange={e=> this.updateInput("newItem",e.target.value)}
              />
          

              <button onClick={()=> this.addItem()}>
                ADD
              </button>
              
                   
              
              <br/>
              <br/>
              
              <ul>
              {this.state.list.map(item=>{
                  return(
                    <li key={item.id}>
                      {item.value}

                      &nbsp;
                      &nbsp;
                      &nbsp;

                      <button onClick={()=>this.deleteItem(item.id)}>
                        
                        Clear
                      
                      </button>

                    </li>
                  )
              })}
              </ul>
              

           </div>



        </div>
    );
  }

}

export default App;
