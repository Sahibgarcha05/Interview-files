
import { observable } from 'mobx';

// Independent Model

export const Model = observable(
    {
        array:[],
        like:0
    }
);

// This method returnig the array

Model.getdata = function(){
    return this.array;
}


// Method defines and call the API
// Fetching data arrays from API

Model.getValue = async function(){

// building an API rerquest
const ApiRequest={ }

// Define API endpoint
const ApiEndpoint= "http://s28.ca/sodv2201/instructor/ratings";

//sending a POST request to API endpoint and calling API
let ApiResponse = await fetch(ApiEndpoint, { method:'POST', body:JSON.stringify(ApiRequest) });

// converting http reply from JSON to
let Reply = await  ApiResponse.json();
var Sample_data = Reply.Ratings;

// testing ---
console.log(Reply.Ratings);


let data_array=[];    // leting an empty array to push the data in it.
        
// using foreach loop for taking the values from array data
   
 Sample_data.Instructors.forEach(element => {                // going through each element of Instructors array 
  Sample_data.Schools.forEach(element_school => {           // going through each element of Schools array 
   Sample_data.Ratings.forEach(element_rating => {          // going through each element of Rating  array 
     Sample_data.Likes.forEach(element_like => {            // going through each element of Likes array 
       
       

if (element.InstructorSid === element_rating.InstructorSid)     
{
   if (element_school.SchoolSid === element_rating.SchoolSid) 
   {
    if(element_like.InstructorSid === element.InstructorSid)  
    {
   
          // pushing data in the array
          data_array.push({               
                            name:element.Instructor,        // pushing the In Instructor name
                            SchoolName:element_school.Name, // pushing the In School name
                            Rate:element_rating.Rating,     // pushing the Rating of Instrutor
                            Like:element_like.Likes         // pushing the likes of Instrutor

                            })     
                         }                    
                    }
                 }   
            });
        });
    });  
});



this.array = data_array;

//console.log(data_array)
//console.log(this.array)

};

//---------------------

// Method increses the number of like of particular instruction

Model.LikeIncrese =  function(like){

this.like = like
this.like = this.like + 1;  // increment like by one
console.log(this.like)

}

   
    

