import React, { Component } from 'react';
import { CARDS } from './cards';       // importing a card file component
import './App.css';                   // importing a App file component



export class Main  extends Component {
    render() { 

        return (  <div className="App">
      
       
        <div className="menu">
        <div></div>
        <div></div>
        <div></div>
            
          </div>


         <div className="logo">
          logo
          </div>

        <div>
        <CARDS model_card = {this.props.model_base}  >
        </CARDS> 

        </div>
        
          

      
    </div> );
    }
}
 
