import React, { Component } from 'react'; // importing a named component
import { observer } from 'mobx-react';


//Class :  Button
// Creating a class component 
export const BUTTON = observer(
 class Button extends Component {
    
  
    // creating a onClick method to count and increment of the likes 
    onclick=()=>{

        this.props.model_base.LikeIncrese(this.props.val)
    }

    render() { 
        return (            
            
        <button onClick={this.onclick}>{this.props.val}

        </button>
        
        );
    }
    }
);
