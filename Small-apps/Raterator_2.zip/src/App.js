import React, { Component } from 'react'; // importing a named component
import './App.css';                       // importing CSS file component
import { observer } from 'mobx-react';
import  { BrowserRouter,Route,Switch } from 'react-router-dom';
import {SplashPage} from './splash-page';
import { MessagePage } from './message-page.js';
import { Main } from './MainPage';


//Class :  App
// Creating a class to handle all the components of application

const App = observer(
class App1 extends Component {


// Render method returns the main form of the app
// returning components  which includes all the information in array of sample data
  render() {
  
   
    return (
     

      <BrowserRouter>
      <Switch>

      <Route exact path="/splash" render={ props => <SplashPage {...props} /> } />
      <Route exact path="/" render={ props => <Main model_base={this.props.model} {...props} /> } />

      <Route render={ props => <MessagePage message="We could not find that page (404)." {...props} /> } />


     
      </Switch>
      </BrowserRouter>
    );
  }
}

);
export default App