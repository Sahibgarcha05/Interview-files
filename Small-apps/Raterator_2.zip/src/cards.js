import React, { Component } from 'react'; // importing a named REACT component
import  { BUTTON } from './Likebutton';   // importing a likedbutton component
import './App.css';                       // importing a App file component
import { observer } from 'mobx-react';

//Class :  Card
// Creating a class to handle a sample data of array
// Resulting the values of school name, instructor name , rating and likes from the sample data

export const CARDS = observer ( 
 class Card extends Component {
 

 async componentDidMount() {
   await this.props.model_card.getValue()
  }
  // method printing the required 
    render() {

     let data_array=  this.props.model_card.getdata();
     
     console.log(data_array)
    
    // Returning the values in the particular div elements   
    return (

     data_array.map((element)=>{      // calling the function on each element of array 
    console.log(element)
      return(
       
        
        <div className="main_card">
        
        

        <div className="Instructor">
                       
        <span>{element.name}</span>
        
        </div>
        
        <div className="college">
        <span>{element.SchoolName}</span>
        </div>

        <div className="stars">
        <span>{element.Rate}</span>
    
        <i className="fas fa-star"></i>
        <i className="fas fa-star"></i>
        <i className="fas fa-star"></i>
        <i className="fas fa-star"></i>
        <i className="fas fa-star"></i>
        </div>

        <div className="footer" >

        Likes  
        <BUTTON  val={element.Like} model_base = {this.props.model_card}  />
    
      
       

        <input type="button" className="button1" value="SHOW REVEWS">
        </input>
       
       
        </div>    

      

    </div>      )
    })

   )  // closing return function
      
             
        

  } // closing the render method
           
}  // closing class
 
);


