
import React, { Component } from 'react';

export class SplashPage extends Component{

    constructor(props){
        super(props);
        this.SplashPageTimer = null;
    }

    componentDidMount(){
        this.SplashPageTimer = setTimeout(this.onSplashPageTimeout, 2000);

    }

    componentWillMount(){
        this.SplashPageTimer = null;
    }

    onSplashPageTimeout = () =>{
        this.props.history.replace("/");
    }


    render(){
        return(
            <div>
                <h1>Now loading...</h1>

                </div>
        );
    }
}