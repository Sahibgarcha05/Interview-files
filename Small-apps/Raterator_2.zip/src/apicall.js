import{
    configure,
    action,
    observable,
    runInAction,
    flow,
    decotate

} from "mobx";


class apicall{
   
  



}