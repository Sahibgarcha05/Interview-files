﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    
    /// <summary>
    /// Class setting up the fields for Ranks and Files for the pieces of chess 
    /// </summary>
    public abstract class Piece
    {
        public int rank;
        public char file;

        /// <summary>
        /// Initializes parameters using constructor
        /// </summary>
        /// <param name="rank_cons"></param>
        /// <param name="file_cons"></param>
        
        public Piece(int rank_cons, char file_cons)
        {
            rank = rank_cons;
            file = file_cons;
        }

        /// <summary>
        /// Function giving piece's postion in standard notation 
        /// </summary>
        public void Piece_location()
        {
            Console.WriteLine(file + rank);
        }

        /// <summary>
        /// Function check the piece destination to be moved
        /// </summary>
        /// <param name="ToRank"></param>
        /// <param name="ToFile"></param>
        /// <returns></returns>
        public abstract bool CanMoveTo(int ToRank, char ToFile);

        /// <summary>
        /// Fucntion moves the piece to the given destination
        /// Uses abstract function to validate move of piece 
        /// </summary>
        /// <param name="ToRank"></param>
        /// <param name="ToFile"></param>
        /// <returns></returns>
        public bool MovePiece(int ToRank, char ToFile)
        {
            if (CanMoveTo(ToRank, ToFile) == true)
            {
                rank = ToRank;
                file = ToFile;
                return true;
            }
            else
            {
                return false;
            }

        }
    }



    /*-----------------------------------------------------------------------------*/
    /*-----------------------------------------------------------------------------*/


    /// <summary>
    /// Class for Pawn Piece of chess
    /// contains a constructor and a function for moves
    /// </summary>
    public class Pawn : Piece
    {
        /// <summary>
        /// Initializes parameters using base constructor 
        /// </summary>
        /// <param name="rank_cons"></param>
        /// <param name="file_cons"></param>
        public Pawn(int rank_cons, char file_cons) : base(rank_cons, file_cons)
        {
            rank = rank_cons;
            file = file_cons;
        }


        /// <summary>
        /// Function checks the valid move for the pawn piece
        /// </summary>
        /// <param name="ToRank"></param>
        /// <param name="ToFile"></param>
        /// <returns></returns>
        public override bool CanMoveTo(int ToRank, char ToFile)
        {

            if (rank == 2)              // When the piece is at Rank 2 (From Starting)
            {
                if (ToRank == rank + 1)
                {
                    return true;
                }
                else if (ToRank == rank + 2)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            if (rank > 2 && rank < 8)    // Normal one move up
            {
                if (ToRank == rank + 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }

            if (file != 'a' && rank >= 2 && rank < 8)      // Left diagnoal move
            {
                if (ToRank == rank + 1 && ToFile == file + 1)
                {
                    return true;
                }

                else
                {
                    return false;
                }
            }

            if (file != 'h' && rank >= 2 && rank < 8)      // Right Diagnoal
            {
                if (ToRank == rank + 1 && ToFile == file + 1)
                {
                    return true;
                }

                else
                {
                    return false;
                }
            }

            else
            {
                return false;
            }


        }
    }


    /*-----------------------------------------------------------------------------*/
    /*-----------------------------------------------------------------------------*/

    /// <summary>
    ///  Class for Rook Piece of chess
    ///  contains a base constructor and a function for moves
    /// </summary>
    public class Rook : Piece
    {

        /// <summary>
        /// Initializes parameters using base constructor
        /// </summary>
        /// <param name="ranl_cons"></param>
        /// <param name="file_cons"></param>
        public Rook(int ranl_cons, char file_cons) : base(ranl_cons, file_cons)
        {
            rank = ranl_cons;
            file = file_cons;
        }

        /// <summary>
        /// Function checks the valid move for the Rook piece
        /// </summary>
        /// <param name="ToRank"></param>
        /// <param name="ToFile"></param>
        /// <returns></returns>
        public override bool CanMoveTo(int ToRank, char ToFile)
        {
           

                if (ToRank >= 1 && ToRank <= 8 && ToFile == file && ToRank != rank)             //  Up and Down move of Rook piece
                {
                  return true;
                }

                else if (ToFile >= 'a' && ToFile <= 'h' && ToRank == rank && ToFile != file)    // Right and Left Move of Rook piece
                {
                    return true;
                }

                else
                {
                    return false;
                }
         
        }

    }

    /*-----------------------------------------------------------------------------*/
    /*-----------------------------------------------------------------------------*/

    /// <summary>
    ///  Class for Bishop Piece of chess
    ///  contains a base constructor and a function for moves
    /// </summary>
    public class Bishop : Piece
        {


        /// <summary>
        /// Initializes parameters using base constructor
        /// </summary>
        /// <param name="ranl_cons"></param>
        /// <param name="file_cons"></param>
        public Bishop(int ranl_cons, char file_cons) : base(ranl_cons, file_cons)
            {
                rank = ranl_cons;
                file = file_cons;
            }

        /// <summary>
        /// Function checks the valid move for the Bishop piece
        /// </summary>
        /// <param name="ToRank"></param>
        /// <param name="ToFile"></param>
        /// <returns></returns>
        public override bool CanMoveTo(int ToRank, char ToFile)
            {

            if (ToRank >= 1 && ToRank <= 8 && ToFile >= 'a' && ToFile <= 'h')       // Condition for the piece in the chess board
            {

                if ((ToRank > rank) == (ToFile > file) && (ToRank != rank && ToFile != file))   // Condition for UP Digonal move
                {
                    return true;
                }

               else if ((ToRank < rank) == (ToFile < file) && (ToRank != rank && ToFile != file))   // Condition for Down Digonal move
                {
                    return true;
                }

                else
                {
                    return false;
                }
            }
            
           
            else
            {
                return false;
            }


            }
        }


    /*-----------------------------------------------------------------------------*/
    /*-----------------------------------------------------------------------------*/


        /// <summary>
        /// Class setting up a field for a list of pieces
        /// </summary>
    public class Chess
    {
      
        /// <summary>
        /// List holds the pieces which are currently added to board
        /// </summary>
        public List<Piece> List_Pieces = new List<Piece>();

        /// <summary>
        /// Function adds piece to the board
        /// </summary>
        /// <param name="addPiece"></param>
        public void AddPiece(Piece addPiece)
        {
            List_Pieces.Add(addPiece);
        }


        /// <summary>
        /// Function moves the pieces to given location to given destination
        /// </summary>
        /// <param name="fromRank"></param>
        /// <param name="fromFile"></param>
        /// <param name="toRank"></param>
        /// <param name="toFile"></param>
        /// <returns></returns>
        public bool MovePiece(int fromRank, char fromFile, int toRank, char toFile)
        {
         
            for (int i = 0; i < List_Pieces.Count(); i++)
            {

                if (List_Pieces[i].CanMoveTo(toRank, toFile) == true)
                {
                    toRank = fromRank;
                    toFile = fromFile;
                    return true;
                }
                else
                {
                    return false;
                }
            }

            return false;

        }

    }


            class Program
            {
                static void ParseLocation(string location, ref int rank, ref char file)
                {
                    rank = int.Parse(location[1].ToString());
                    file = location[0];
                }

                static void Main(string[] args)
                {
                    var chess = new Chess();
                    string command = "";
                    while (command != "exit")
                    {
                        command = Console.ReadLine();
                        var cmdArgs = command.Split();
                        if (cmdArgs.Length == 0)
                            continue;
                        if (cmdArgs[0] == "add")
                        {
                            var type = cmdArgs[1];
                            var location = cmdArgs[2];
                            int rank = 0;
                            char file = '\0';
                            ParseLocation(location, ref rank, ref file);
                            Piece piece = null;
                            if (type == "pawn")
                                piece = new Pawn(rank, file);
                            else if (type == "rook")
                                piece = new Rook(rank, file);
                            else if (type == "bishop")
                                piece = new Bishop(rank, file);
                            chess.AddPiece(piece);
                        }
                        else if (cmdArgs[0] == "move")
                        {
                            var fromLocation = cmdArgs[1];
                            var toLocation = cmdArgs[2];
                            int fromRank = 0;
                            char fromFile = '\0';
                            int toRank = 0;
                            char toFile = '\0';
                            ParseLocation(fromLocation, ref fromRank, ref fromFile);
                            ParseLocation(toLocation, ref toRank, ref toFile);
                            bool moved = chess.MovePiece(fromRank, fromFile, toRank, toFile);
                            Console.WriteLine("Move " + (moved ? "succeeded" : "failed"));
                        }
                    }
                }
            }
        }
    

