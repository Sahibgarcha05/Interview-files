import { observable } from 'mobx';


// Independent Model


export const Model = observable(

    { 
		EmailAddress:"", 
		Password:"",
		Array:[],
		Array2:[]
	}

);

// Login

//console.log("Model Test");

// Method defines and call the API
// Fetching data array from API
Model.Login = async function() {

	try {

		// Defines API Endpoint.
		const Endpoint = "http://s28.ca/rest/bowspace/login";

		// Convert the payload to JSON.
		// building an API rerquest
		const ApiRequest = JSON.stringify(
			{
				EmailAddress:this.EmailAddress,
				Password:this.Password
			}
		);

		// Build out the request body.  The x-amz-* headers are required by AWS.
		let FetchData = { 
			method:'POST',
			mode:'cors', 
			cache:'no-cache', 
			credentials:'omit',
			headers: {
				'Content-Type': 'application/octet-stream',
				'Content-Length': ApiRequest.length,
			},
			body: ApiRequest
		};

		// Start the async call.
		//sending a POST request to API endpoint and calling API

		console.log("[model.js] Preparing to fetch/put, payload -->"); console.log(Endpoint); console.log(FetchData);
		let FetchReply = await fetch(Endpoint, FetchData);
		console.log("Heard back from fetch/put --> "); console.log(FetchReply);

		
		// converting http reply from JSON to
		let ApiReply = await FetchReply.json();
		console.log("ApiReply --> "); console.log(ApiReply);

		if(ApiReply.Status === "success"){
			

			// JWT TOKEN

			const temp=ApiReply.Jwt.split('.')[1];
		//	console.log(temp);

			const func = window.atob(temp);

			const res=JSON.parse(func);
			
			// testing ---
			console.log(res);

			//********************** */
		
			
		}


		// Return true/false based on http status.
		return (FetchReply.status === 200);

	} catch(e) {

		console.log("[Model] Exception! e -->"); console.log(e);

	}	

}


///
/// SetEmailAddress
///
Model.SetEmailAddress = function(newvalue) {
	this.EmailAddress = newvalue;
}

///
/// SetPassword
///
Model.SetPassword = function(newvalue) {
	this.Password = newvalue;
}


//****************************** */
//****************************** */


	// Method defines and call the API
	// Fetching data arrays from API

	Model.Search =async function(){

		// testing--
		console.log("search function test runnig");

		try{
	
		// Define API endpoint
		const Endpoint = "http://s28.ca/rest/bowspace/users";


		// Convert the payload to JSON.
		const ApiRequest = JSON.stringify(
			{
				Jwt: ""
			}
		);

		// Build out the request body.  The x-amz-* headers are required by AWS.
			let FetchData = { 
			method:'POST',
			mode:'cors', 
			cache:'no-cache', 
			credentials:'omit',
			headers: {
				'Content-Type': 'application/octet-stream',
				'Content-Length': ApiRequest.length,
			},
			body: ApiRequest
		};


		
		// Start the async call.
		//sending a POST request to API endpoint and calling API

		console.log("[model.js] Preparing to fetch/put, payload -->"); console.log(Endpoint); console.log(FetchData);
		let FetchReply = await fetch(Endpoint, FetchData);
		console.log("Heard back from fetch/put --> "); console.log(FetchReply);

		
		// converting http reply from JSON 

		let ApiReply = await FetchReply.json();
		console.log("ApiReply --> ");
		 console.log(ApiReply);
		 
		 //testing--
		 console.log(ApiReply.MatchingUsers);


		this.Array = ApiReply.MatchingUsers;

		//------
	
		}

		catch(e){
			console.log("[Model] Exception! e -->"); console.log(e)
		}

	}

	// method puts to value into the Array
	Model.EachUserSearch = function(){
		return this.Array;
	}



//****************************** */
//****************************** */


// Method defines and call the API
// Fetching data arrays from API

Model.SearchPost =async function(){
		
	console.log("search post function");// For testing

	try{

		// Define API endpoint
		const Endpoint = "http://s28.ca/rest/bowspace/posts";


		// building an API rerquest
		const ApiRequest = JSON.stringify(
			{
				Jwt: ""
			}
			);


		// Build out the request body.  The x-amz-* headers are required by AWS.

		let FetchData = { 
			method:'POST',
			mode:'cors', 
			cache:'no-cache', 
			credentials:'omit',
			headers: {
				'Content-Type': 'application/octet-stream',
				'Content-Length': ApiRequest.length,
			},
			body: ApiRequest
		};


		
		//sending a POST request to API endpoint and calling API
		console.log("[model.js] Preparing to fetch/put, payload -->"); console.log(Endpoint); console.log(FetchData);
		let FetchReply = await fetch(Endpoint, FetchData);
		console.log("Heard back from fetch/put --> "); console.log(FetchReply);

		// converting http reply from JSON 
		let ApiReply = await FetchReply.json();
		console.log("ApiReply --> ");
		console.log(ApiReply.MatchingPosts);	// Testing--

		this.Array2 = ApiReply.MatchingPosts;

	}
	catch(e){
		console.log("[Model] Exception! e -->"); console.log(e)

	}
}

	Model.EachPostSearch = function(){
		return this.Array2;
	}



//***************************************** */
//******************************************* */

	Model.CreatePost =async function(){
		
	console.log("Create post function");

		
	try{
			// Endpoint.
		const Endpoint = "http://s28.ca/rest/bowspace/post";


		const ApiRequest = JSON.stringify(
			{
				Jwt: "", // The login token attached to the authenticated user.
				SenderSid: "", // The unique identifier of the sending user.
				RecipientSid: "", // The unique identifier of the recipient user.
				PostBody: "" // The body of the post.
			}
		);
		

		let FetchData = { 
			method:'POST',
			mode:'cors', 
			cache:'no-cache', 
			credentials:'omit',
			headers: {
				'Content-Type': 'application/octet-stream',
				'Content-Length': ApiRequest.length,
			},
			body: ApiRequest
		};

		// Start the async call.
		console.log("[model.js] Preparing to fetch/put, payload -->"); console.log(Endpoint); console.log(FetchData);
		let FetchReply = await fetch(Endpoint, FetchData);
		console.log("Heard back from fetch/put --> "); console.log(FetchReply);

		
		let ApiReply = await FetchReply.json();
		console.log("ApiReply --> ");
		console.log(ApiReply);


	}

	catch(e){
		console.log("[Model] Exception! e -->"); console.log(e)


	}

}


Model.Reset = async function() {

	this.EmailAddress = "";
	this.Password = "";

}







