///
// Login Page
///


import React, { Component } from 'react';
import './App.css';
import { observer } from 'mobx-react';
import icon from './icon.png';


// Login

export const Login = observer(
  class Login extends Component{


    // OnLogin 
    //calling the the Login method from model
    // navigate to main Landing page
    OnLogin=(e)=>{
       
         this.props.model.Login();

         this.props.history.push("/LandingPage");
         
      
     }
    

   
     // On change Email Address
     // Checking the Email which user typed with API
    onChangeEmailAddress=(e)=>{
       const NewValue = e.target.value;
       this.props.model.SetEmailAddress(NewValue);

     }

     // On change Password
     // Checking the Password which user typed with API
    OnChangePassword = (e) => {

        // Extract value from the event object.
        const NewValue = e.target.value;
        
        // Update the model using a model method.
        this.props.model.SetPassword(NewValue);

        

    }

    render(){

       console.log("login test");
      
      const EmailAddress = this.props.model.EmailAddress;
      const Password = this.props.model.Password;

          return(
          
           
            <div className="login_main">
                
             

                    <div className="login_page">
          
                        </div>

                        <div className="image">
                         <img src={icon} alt="icon" className="icon_image"/>
                        </div>


                         <div className="Form">

  


                            <div className="logo">
                             Login
                           </div>

                <div className="User">
                    User Name :<input type="text" className="name" onChange={this.onChangeEmailAddress} Email = {EmailAddress} />
                </div>

                <div className="Password">
                    Password: <input type="Password" className="password" onChange={this.OnChangePassword} Password= {Password}/>
                </div>
                

                <div className="button">
                <button type="button" className="login_button" onClick={this.OnLogin} > LOG IN</button>
                </div>


              

                 </div>
        </div>




    );
  }
}


);
