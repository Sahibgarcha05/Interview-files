/// 
/// App.js Page
///


import React, { Component } from 'react';
import './App.css';
import {Login} from "./Login.js";
import {Landing} from "./Landing.js";
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import {Model} from "./model.js";
import { MessagePage } from './message-page.js';
import { SplashPage } from './splash-page.js';

// App
  export class App extends Component{

    // rendering 
    render(){
        console.log("App test");
          return(
    
            //  Defining URL routing and setting path of each page

            <BrowserRouter>
            
            <Switch>

            
            
            <Route exact path="/splash" render={ props => <SplashPage {...props} /> } />

            <Route exact path="/LandingPage" render={ props => <Landing landingmodel={Model}{...props} /> } />
            
            <Route exact path="/" render={props=> <Login model={Model}{...props}/>} />
          
          	<Route render={ props => <MessagePage message="We could not find that page (404)." {...props} /> } />
            </Switch>

            </BrowserRouter>
              
           
    );
  }
}


