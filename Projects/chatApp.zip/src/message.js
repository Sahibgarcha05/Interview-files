import React, { Component } from 'react';
import './App.css';
import { observer } from 'mobx-react';


export const Message = observer(
    class Message extends Component{



        render(){

            console.log("login test");
         
     
               return(

                <div>
                   {message}
                    
                </div>
               )

               

        }


    }
)
    