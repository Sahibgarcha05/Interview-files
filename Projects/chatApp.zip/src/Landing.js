/// Landing Page

import React, { Component } from 'react';
import './landing_page.css';
import {BrowserRouter as Router,Switch,Route} from 'react-router-dom';
import { observer } from 'mobx-react';



/// Class: Landing

export const Landing = observer(
    class Landing extends Component{


        // Onsearch
        // This method taking the all the inforamtion of users from API 
        // and print only Email an Username
        OnSearch = (e) =>{

            this.props.landingmodel.Search();    
          
        }

        //Onsearch
        // This mehod search all the availavle post 
        OnSearchPost =(e)=>{
            this.props.landingmodel.SearchPost();
        }

        // On post
        // Creating and updating a post
        OnPost =(e)=>{
            this.props.landingmodel.CreatePost();
           
        }

        // OnLogout
        // Navigates to logut Page
        OnLogout=(e)=>{
            console.log("Logut");
            this.props.history.goBack("/");

        }

        render(){
        
            console.log("Landing page");

            // Puting the required information in the arrays
            
            let array_list = this.props.landingmodel.EachUserSearch(); 
            let array_list2 = this.props.landingmodel.EachPostSearch();
            return(

                


                <div className="main_landing">
                    <div className="div1">

                            <div className = "new_group">
                            <button type="button" className="newgroup_btn"  > New Group chat</button>
                            </div>

                            <div className="search">
                            <input type="text" className="user" placeholder="Search User"/> 
                            <button type="button" className="search_btn" onClick={this.OnSearch} > Search </button>
                            </div>



                            <div className="group_available">
                                    <div className="Showusers">
                                    { array_list.map((element)=>{      // calling the function on each element of array 
                                        console.log(element)
                                        return(
                                            <div className="Eachuser">
                                            <div>
                                                {element.EmailAddress}
                                                
                                            </div>
                                            <div>
                                                {element.UserName}
                                            </div>
                                        </div>
                                            );
                                        })
                                        }
                                    </div>
                            </div>

                    </div>


                    <div className="div2">

                        <div className="search_post">
                        
                        <input type="text" className="post" placeholder="Search Post"/> 
                        <button type="button" className="search_post_btn" onClick={this.OnSearchPost} > Search </button>


                        <div className="chat_area">

                        
                        
                        { array_list2.map((element)=>{      // calling the function on each element of array 
                        console.log(element)
                        return(
                            
                            <div className="EachPost">
                            <div>
                                {element.PostHtml}
                                
                            </div>
                            <div>
                                {element.Sender}
                            </div>
                            <div>
                                {element.Recipient}
                            </div>
                        </div>
                            );
                        })
                        }
              
                         </div>
                        
                        <div className="send">
                        <input type="text" className="message" placeholder="Type Message"/> 
                        <button type="button" className="send_mssg_btns" onClick={this.OnPost} > Send </button>
                        </div>



                        </div>

                    </div>
                        


                    <div className="div3">
                    <button type="button" className="logout_btn" onClick={this.OnLogout} > LOGOUT </button>

                        </div>

                 </div>
            );
        
        }

    }

)