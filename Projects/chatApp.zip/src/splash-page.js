
// Splash Page

import React, { Component } from 'react'
import "./message.css";

export class SplashPage extends Component{


    constructor(props){
        super(props);
        this.SplashPageTimer = null;
    }


    componentDidMount() {

		// Create a timer to switch away from the splash page after a 2 sec delay.
		this.SplashPageTimer = setTimeout(this.OnSplashPageTimeout, 2000);

	}

    componentWillUnmount() {
		// Remove the reference to the timer to GC can deallocate it.
		this.SplashPageTimer = null;		
    }
	
	
	// Navigate to Login Page
    OnSplashPageTimeout = () => {
		this.props.history.replace("/");
    }
    

    render() {

		return (

			<div className="splashdiv">

				<h1> Welcome to Chat App</h1>

				<div>Now loading...</div>

			</div>

		);

	}

}