﻿namespace schoolapp
{
    partial class studentAddmission
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.Submit = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Last_Name = new System.Windows.Forms.TextBox();
            this.Phn_number = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.TextBox();
            this.Course_Name = new System.Windows.Forms.TextBox();
            this.Course_id = new System.Windows.Forms.TextBox();
            this.First_Name = new System.Windows.Forms.TextBox();
            this.Student_Id = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(394, 517);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 36);
            this.button2.TabIndex = 33;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // Submit
            // 
            this.Submit.Location = new System.Drawing.Point(191, 517);
            this.Submit.Name = "Submit";
            this.Submit.Size = new System.Drawing.Size(75, 38);
            this.Submit.TabIndex = 32;
            this.Submit.Text = "Submit";
            this.Submit.UseVisualStyleBackColor = true;
            this.Submit.Click += new System.EventHandler(this.Submit_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(487, 252);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 17);
            this.label8.TabIndex = 31;
            this.label8.Text = "Last Name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(173, 432);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(145, 17);
            this.label7.TabIndex = 30;
            this.label7.Text = "Parent PhoneNumber";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(198, 390);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 17);
            this.label6.TabIndex = 29;
            this.label6.Text = "Email";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(198, 348);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 17);
            this.label5.TabIndex = 28;
            this.label5.Text = "Course Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(198, 299);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 17);
            this.label4.TabIndex = 27;
            this.label4.Text = "Course Id";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(198, 254);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 17);
            this.label3.TabIndex = 26;
            this.label3.Text = "First Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(198, 216);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 17);
            this.label2.TabIndex = 25;
            this.label2.Text = "Student Id ";
            // 
            // Last_Name
            // 
            this.Last_Name.Location = new System.Drawing.Point(585, 249);
            this.Last_Name.Name = "Last_Name";
            this.Last_Name.Size = new System.Drawing.Size(136, 22);
            this.Last_Name.TabIndex = 24;
            // 
            // Phn_number
            // 
            this.Phn_number.Location = new System.Drawing.Point(324, 432);
            this.Phn_number.Name = "Phn_number";
            this.Phn_number.Size = new System.Drawing.Size(145, 22);
            this.Phn_number.TabIndex = 23;
            // 
            // Email
            // 
            this.Email.Location = new System.Drawing.Point(324, 390);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(145, 22);
            this.Email.TabIndex = 22;
            // 
            // Course_Name
            // 
            this.Course_Name.Location = new System.Drawing.Point(324, 348);
            this.Course_Name.Name = "Course_Name";
            this.Course_Name.Size = new System.Drawing.Size(145, 22);
            this.Course_Name.TabIndex = 21;
            // 
            // Course_id
            // 
            this.Course_id.Location = new System.Drawing.Point(324, 299);
            this.Course_id.Name = "Course_id";
            this.Course_id.Size = new System.Drawing.Size(145, 22);
            this.Course_id.TabIndex = 20;
            // 
            // First_Name
            // 
            this.First_Name.Location = new System.Drawing.Point(324, 252);
            this.First_Name.Name = "First_Name";
            this.First_Name.Size = new System.Drawing.Size(145, 22);
            this.First_Name.TabIndex = 19;
            // 
            // Student_Id
            // 
            this.Student_Id.Location = new System.Drawing.Point(324, 213);
            this.Student_Id.Name = "Student_Id";
            this.Student_Id.Size = new System.Drawing.Size(145, 22);
            this.Student_Id.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(370, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 17);
            this.label1.TabIndex = 17;
            this.label1.Text = "Student Addmission";
            // 
            // studentAddmission
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 595);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Submit);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Last_Name);
            this.Controls.Add(this.Phn_number);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.Course_Name);
            this.Controls.Add(this.Course_id);
            this.Controls.Add(this.First_Name);
            this.Controls.Add(this.Student_Id);
            this.Controls.Add(this.label1);
            this.Name = "studentAddmission";
            this.Text = "studentAddmission";
            this.Load += new System.EventHandler(this.StudentAddmission_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button Submit;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Last_Name;
        private System.Windows.Forms.TextBox Phn_number;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.TextBox Course_Name;
        private System.Windows.Forms.TextBox Course_id;
        private System.Windows.Forms.TextBox First_Name;
        private System.Windows.Forms.TextBox Student_Id;
        private System.Windows.Forms.Label label1;
    }
}