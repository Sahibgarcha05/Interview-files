USE master
GO

/***** object: Database GBS ******/

CREATE DATABASE GBS
GO

USE GBS
GO

/****Object: Table Institution */

CREATE TABLE Institution(

	Institution_Name VARCHAR (50) PRIMARY KEY,
	Country VARCHAR (50)

);


/***********************/

/****Object: Table Attendees */

CREATE TABLE Attendees(
	
	Attendee_ID VARCHAR(50) PRIMARY KEY,
	Full_Name VARCHAR(50),
	Mailing_Add VARCHAR(50) NOT NULL ,
	Email Varchar(50),
	DOB DATE,
	Associated_Institution VARCHAR (50) FOREIGN KEY REFERENCES Institution(Institution_Name)
	
);  


/**************************/

/****Object: Table Publications */

CREATE TABLE Publications(
	
	Publication_ID VARCHAR(50) PRIMARY KEY,
	Title VARCHAR(50),
	Publication_Journal VARCHAR(50) NOT NULL,
	Publication_Date DATE NOT NULL,
	Summary VARCHAR (50) 
	
); 


/**************************/

/****Object: Table Attendees_Publication */

CREATE TABLE Attendees_Publication(
	
	 Attendees_ID VARCHAR (50) FOREIGN KEY REFERENCES Attendees (Attendee_ID),
	 Publication_ID VARCHAR (50) FOREIGN KEY REFERENCES Publications (Publication_ID)
	
	
); 



/********************/

/****Object: Table Votes */

CREATE TABLE Votes(

	Attendees_ID VARCHAR (50) FOREIGN KEY REFERENCES Attendees (Attendee_ID),
	Publication_ID VARCHAR (50) FOREIGN KEY REFERENCES Publications (Publication_ID),
	CONSTRAINT Award PRIMARY KEY (Attendees_ID,Publication_ID)							/*Refrence :- https://www.w3schools.com/sql/sql_primarykey.asp */
);