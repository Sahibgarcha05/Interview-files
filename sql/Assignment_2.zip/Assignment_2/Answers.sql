--Course code : DATA3201
--TERM/Year : 2019
--Assignment code: A2
--Author :  Sahibpreet Singh , Tamanjit Singh
--BVC username : s.singh822@mybvc.ca , t.940@mybvc.ca
--Date created : 2019-04-03
--Description : Assignment Two Database manipulation


----------------------------------------
-----------------------------------------

-- ANSWER 1 
SELECT CONCAT(LastName, ',' , ' ' , FirstName) 
AS FullName
FROM Customers
WHERE LastName >= 'M'
ORDER BY FullName ASC

----------------------------------------
-----------------------------------------
-- ANSWER 2
SELECT ProductName , ListPrice , DateAdded
FROM Products
WHERE ListPrice > 500 and ListPrice < 2000
ORDER BY DateAdded DESC

----------------------------------------
-----------------------------------------
-- ANSWER 3
SELECT ItemID , ItemPrice , DiscountAmount , Quantity ,
(ItemPrice * Quantity) AS PriceTotal ,
(DiscountAmount * Quantity)AS DiscountTotal ,
((ItemPrice - DiscountAmount) * DiscountAmount) AS ItemTotal
FROM OrderItems
WHERE ((ItemPrice - DiscountAmount) * DiscountAmount) > 500
ORDER BY ItemTotal DESC

----------------------------------------
-----------------------------------------
-- ANSWER 4
SELECT OrderID , OrderDate , ShipDate 
FROM Orders
WHERE ShipDate IS NULL

----------------------------------------
-----------------------------------------
-- ANSWER 5
SELECT 
(100) AS Price,
(0.07) AS TaxRate,
(100 * 0.07) AS TaxAmount,
(100 + (100 * 0.07)) AS Total

----------------------------------------
-----------------------------------------
-- ANSWER 6
SELECT FirstName , LastName , Line1 , City , [State] , ZipCode
FROM Customers JOIN Addresses
ON Customers.CustomerID = Addresses.CustomerID 
WHERE Customers.EmailAddress = 'allan.sherwood@yahoo.com'

----------------------------------------
-----------------------------------------
-- ANSWER 7
SELECT FirstName , LastName , Line1 , City , [State] , ZipCode
FROM Customers JOIN Addresses
ON Customers.CustomerID = Addresses.CustomerID 
AND
Customers.ShippingAddressID = Addresses.AddressID

----------------------------------------
-----------------------------------------
-- ANSWER 8

SELECT LastName,FirstName,OrderDate,ProductName,
ItemPrice,DiscountAmount,Quantity
FROM Customers
INNER JOIN Orders
ON Customers.CustomerID = Orders.CustomerID
INNER JOIN OrderItems
ON Orders.OrderID=OrderItems.OrderID
INNER JOIN Products
ON OrderItems.ProductID = Products.ProductID


----------------------------------------
-----------------------------------------
-- ANSWER 9
SELECT 'SHIPPED' AS ShipStatus,
OrderID , OrderDate
FROM Orders
WHERE ShipDate IS NOT NULL

UNION

SELECT 'NOT SHIPPED', OrderID, OrderDate
FROM Orders
WHERE ShipDate IS NULL
ORDER BY OrderDate

----------------------------------------
-----------------------------------------
-- ANSWER 10
SELECT CategoryName, ProductID
FROM Categories 
LEFT JOIN 
Products
ON Categories.CategoryID = Products.CategoryID
WHERE ProductID IS NULL

----------------------------------------
-----------------------------------------
-- ANSWER 11
SELECT Categories.CategoryName,
COUNT(ProductID) AS 'Products in the products table',
MAX(ListPrice) AS 'Expensive Products'
FROM Categories
INNER JOIN Products
ON Categories.CategoryID = Products.CategoryID
GROUP BY CategoryName
ORDER BY CategoryName DESC

----------------------------------------
-----------------------------------------
-- ANSWER 12
SELECT EmailAddress,OrderID,OrderDate
FROM Customers
INNER JOIN Orders
ON Customers.CustomerID = Orders.CustomerID
WHERE OrderDate IN (SELECT MIN(OrderDate)
                  FROM Orders
                  WHERE Customers.CustomerID = Orders.CustomerID)

----------------------------------------
-----------------------------------------
-- ANSWER 13
SELECT COUNT(OrderID) AS 'Number of Oredrs',
SUM(TaxAmount) AS 'Sum of Tax Amount'
FROM Orders

----------------------------------------
-----------------------------------------
-- ANSWER 14

SELECT DISTINCT CategoryName 
FROM Categories
WHERE CategoryID 
IN(SELECT CategoryID from Products)

----------------------------------------
-----------------------------------------
-- ANSWER 15
INSERT INTO Customers(EmailAddress,[Password],FirstName,LastName)
VALUES('rick@raven.com','','Rick','Raven')

----------------------------------------
-----------------------------------------
-- ANSWER 16
UPDATE Customers 
SET [Password] = 'Secret'
WHERE EmailAddress = 'rick@raven.com' 

----------------------------------------
-----------------------------------------
-- ANSWER 17

INSERT INTO Categories(CategoryName)
VALUES ('Brass')

----------------------------------------
-----------------------------------------
-- ANSWER 18

DELETE FROM Categories
WHERE CategoryID = 5;




